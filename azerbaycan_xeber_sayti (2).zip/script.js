document.getElementById("searchBox").addEventListener("input", function() {
  const query = this.value.toLowerCase();
  const articles = document.querySelectorAll(".news-card");

  articles.forEach(article => {
    const text = article.textContent.toLowerCase();
    article.style.display = text.includes(query) ? "block" : "none";
  });
});